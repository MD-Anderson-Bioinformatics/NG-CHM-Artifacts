This directory contains externs files for using webgl-debug.js with the Google
Closure compiler.
