# WebGLDeveloperTools

A small repository containing a few useful WebGL developer tools.

Intended to be used as an ES6 module.

Releases:

v1.0.0: Initial [semver tag](http://semver.org/), used for module versioning by module loader.

For more information and other useful tools, consult the WebGL wiki:
http://www.khronos.org/webgl/wiki/
